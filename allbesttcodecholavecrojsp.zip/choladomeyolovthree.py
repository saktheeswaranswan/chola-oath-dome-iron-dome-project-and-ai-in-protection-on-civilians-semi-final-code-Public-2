#sudo apt-get update
#sudo apt-get install python3-tk

import cv2
import numpy as np
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import math
import random
import csv

# -------------------------------
# Initialize YOLO network.
# -------------------------------
net = cv2.dnn.readNetFromDarknet("yolov3-tiny.cfg", "yolov3-tiny.weights")
net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
with open("coco.names", "r") as f:
    classes = [line.strip() for line in f.readlines()]
layer_names = net.getLayerNames()
try:
    output_layers = [layer_names[i[0]-1] for i in net.getUnconnectedOutLayers()]
except Exception:
    output_layers = [layer_names[i-1] for i in net.getUnconnectedOutLayers()]

# -------------------------------
# Open CSV file for logging detections.
# -------------------------------
csv_file = open("detections.csv", "w", newline="")
csv_writer = csv.writer(csv_file)
csv_writer.writerow(["timestamp", "center_x", "center_y", "class"])

# -------------------------------
# YOLO detection function.
# Processes the frame, draws bounding boxes, and logs detection center coordinates.
# -------------------------------
def detect_objects(frame, detection_threshold=0.3):
    height, width = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(frame, 1/255.0, (416, 416), swapRB=True, crop=False)
    net.setInput(blob)
    outs = net.forward(output_layers)
    
    boxes = []
    confidences = []
    class_ids = []
    
    for out in outs:
        for detection in out:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > detection_threshold:
                center_x = int(detection[0] * width)
                center_y = int(detection[1] * height)
                w = int(detection[2] * width)
                h = int(detection[3] * height)
                x = int(center_x - w/2)
                y = int(center_y - h/2)
                boxes.append([x, y, w, h])
                confidences.append(float(confidence))
                class_ids.append(class_id)
    
    indices = cv2.dnn.NMSBoxes(boxes, confidences, detection_threshold, 0.4)
    if len(indices) > 0:
        for i in indices.flatten():
            x, y, w, h = boxes[i]
            center_x = x + w // 2
            center_y = y + h // 2
            label = str(classes[class_ids[i]])
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
            cv2.putText(frame, label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX,
                        0.5, (0, 255, 0), 2)
            csv_writer.writerow([int(cv2.getTickCount()), center_x, center_y, label])
    return frame

# -------------------------------
# Initialize webcam.
# Tries indices 0 and 1. If neither is available, returns None.
# -------------------------------
def init_camera(indices=[0, 1]):
    cap = None
    for idx in indices:
        cap_temp = cv2.VideoCapture(idx)
        if cap_temp.isOpened():
            print(f"Camera index {idx} opened.")
            cap = cap_temp
            break
        else:
            cap_temp.release()
    return cap

cap = init_camera()

# -------------------------------
# Setup Tkinter UI.
# -------------------------------
root = tk.Tk()
root.title("Tkinter YOLO Detection")

canvas_width = 800
canvas_height = 600
canvas = tk.Canvas(root, width=canvas_width, height=canvas_height)
canvas.pack()

# Create a slider to adjust the YOLO detection threshold.
threshold_scale = tk.Scale(root, from_=0.1, to=1.0, resolution=0.05, 
                           orient=tk.HORIZONTAL, label="Detection Threshold")
threshold_scale.set(0.3)
threshold_scale.pack()

# -------------------------------
# Update loop for video frames.
# -------------------------------
def update_frame():
    if cap is not None:
        ret, frame = cap.read()
        if not ret:
            # If frame capture fails, create a blank image.
            frame = np.zeros((canvas_height, canvas_width, 3), dtype=np.uint8)
            cv2.putText(frame, "No frame", (50, canvas_height // 2),
                        cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 255), 3)
    else:
        # No webcam available; create a placeholder image.
        frame = np.zeros((canvas_height, canvas_width, 3), dtype=np.uint8)
        cv2.putText(frame, "No Webcam Available", (50, canvas_height // 2),
                    cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 255), 3)
    
    # Get the current threshold from the slider.
    detection_threshold = threshold_scale.get()
    processed_frame = detect_objects(frame, detection_threshold)
    
    # Convert the processed frame to a PIL image and then to an ImageTk.PhotoImage.
    image = cv2.cvtColor(processed_frame, cv2.COLOR_BGR2RGB)
    image = Image.fromarray(image)
    imgtk = ImageTk.PhotoImage(image=image)
    canvas.imgtk = imgtk
    canvas.create_image(0, 0, anchor=tk.NW, image=imgtk)
    
    root.after(30, update_frame)

update_frame()
root.mainloop()

if cap is not None:
    cap.release()
csv_file.close()

