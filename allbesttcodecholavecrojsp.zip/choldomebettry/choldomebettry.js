// Global parameters
const dome_radius = 300;          // Dome radius
const second_dome_radius = 310;   // For reference (base circle)
let speed_factor = 0.5;

// Camera parameters
let zoom_factor = 1.0;
let camera_yaw = 0.0;
let camera_pitch = 0.0;

// Array for permanent track points (red dots)
let trackPoints = [];

// Webcam video and slider for patch size
let video;
let patchSlider;

// Timing for trajectory generation
let lastTrajectoryTime = 0;
let trajectoryInterval = 1000; // generate one trajectory per second

function setup() {
  createCanvas(800, 600, WEBGL);
  // Create and hide the video capture (we use it as texture)
  video = createCapture(VIDEO);
  video.size(320, 240);
  video.hide();
  
  // Create a slider to control the angular span of the webcam patch (in radians)
  patchSlider = createSlider(0.1, 1.0, 0.5, 0.01);
  patchSlider.position(20, 20);
}

function draw() {
  background(0);
  
  // Allow mouse to orbit the view
  orbitControl();
  
  // Update patch angle from slider value
  let patchAngle = patchSlider.value();
  
  // Draw the transparent half-spherical dome
  drawDome();
  // Draw the base plane (circle)
  drawBasePlane();
  // Draw the webcam patch on one side of the dome's interior
  drawWebcamPatch(patchAngle);
  
  // Every trajectoryInterval ms, generate and draw a new parabolic trajectory
  if (millis() - lastTrajectoryTime > trajectoryInterval) {
    drawTrajectory();
    lastTrajectoryTime = millis();
  }
  
  // Draw permanent track points (red spheres)
  drawTrackPoints();
}

// Draw a transparent half-spherical dome (upper hemisphere)
function drawDome() {
  push();
  noStroke();
  fill(100, 100, 255, 50);
  let domeDetail = 30;
  for (let i = 0; i < domeDetail; i++) {
    let theta1 = map(i, 0, domeDetail, 0, PI/2);
    let theta2 = map(i + 1, 0, domeDetail, 0, PI/2);
    beginShape(TRIANGLE_STRIP);
    for (let j = 0; j <= domeDetail; j++) {
      let phi = map(j, 0, domeDetail, 0, TWO_PI);
      let x1 = dome_radius * sin(theta1) * cos(phi);
      let y1 = dome_radius * cos(theta1);
      let z1 = dome_radius * sin(theta1) * sin(phi);
      vertex(x1, y1, z1);
      let x2 = dome_radius * sin(theta2) * cos(phi);
      let y2 = dome_radius * cos(theta2);
      let z2 = dome_radius * sin(theta2) * sin(phi);
      vertex(x2, y2, z2);
    }
    endShape();
  }
  pop();
}

// Draw the base circle (plane) at y = 0
function drawBasePlane() {
  push();
  noStroke();
  fill(150, 150, 150, 100);
  beginShape();
  let baseDetail = 100;
  for (let i = 0; i < baseDetail; i++) {
    let angle = map(i, 0, baseDetail, 0, TWO_PI);
    let x = dome_radius * cos(angle);
    let z = dome_radius * sin(angle);
    vertex(x, 0, z);
  }
  endShape(CLOSE);
  pop();
}

// Draw a textured patch on one side of the dome's interior using the webcam feed
// The patch is built using spherical coordinates; its angular span is controlled by patchAngle.
function drawWebcamPatch(patchAngle) {
  push();
  // Apply the video texture
  texture(video);
  noStroke();
  
  // Define patch boundaries in spherical coordinates:
  // We'll set a starting polar angle (theta) and azimuthal angle (phi)
  let thetaStart = 0.4;  // (in radians) from the vertical
  let phiStart = 0;      // patch on one side
  let patchRows = 20;
  let patchCols = 20;
  
  // Draw the patch as a grid of quads using TRIANGLE_STRIP rows
  for (let i = 0; i < patchRows; i++) {
    let theta0 = thetaStart + (i / patchRows) * patchAngle;
    let theta1 = thetaStart + ((i + 1) / patchRows) * patchAngle;
    beginShape(TRIANGLE_STRIP);
    for (let j = 0; j <= patchCols; j++) {
      let phi = phiStart + (j / patchCols) * patchAngle;
      
      // Compute vertex for row i
      let x1 = dome_radius * sin(theta0) * cos(phi);
      let y1 = dome_radius * cos(theta0);
      let z1 = dome_radius * sin(theta0) * sin(phi);
      let u1 = j / patchCols;
      let v1 = i / patchRows;
      vertex(x1, y1, z1, u1, v1);
      
      // Compute vertex for row i+1
      let x2 = dome_radius * sin(theta1) * cos(phi);
      let y2 = dome_radius * cos(theta1);
      let z2 = dome_radius * sin(theta1) * sin(phi);
      let u2 = j / patchCols;
      let v2 = (i + 1) / patchRows;
      vertex(x2, y2, z2, u2, v2);
    }
    endShape();
  }
  pop();
}

// Draw a parabolic trajectory from a random point above the dome to a random point on its base.
// When the trajectory enters the dome (its radial xz-distance is less than dome_radius), it is drawn in red,
// and the point is recorded as a permanent red track.
function drawTrajectory() {
  let numSegments = 30;
  // Random start (outside the dome)
  let r_start = random(dome_radius + 50, dome_radius + 150);
  let angle_start = random(TWO_PI);
  let startX = r_start * cos(angle_start);
  let startZ = r_start * sin(angle_start);
  let startY = dome_radius + 100;
  
  // Random end (on the base, inside the dome)
  let r_end = random(0, dome_radius);
  let angle_end = random(TWO_PI);
  let endX = r_end * cos(angle_end);
  let endZ = r_end * sin(angle_end);
  let endY = 0;
  
  // Control point for the quadratic Bezier (with downward bias)
  let ctrlX = (startX + endX) / 2;
  let ctrlY = (startY + endY) / 2 - 50;
  let ctrlZ = (startZ + endZ) / 2;
  
  // Draw the trajectory curve and record track points when inside the dome
  beginShape();
  for (let i = 0; i <= numSegments; i++) {
    let t = i / numSegments;
    // Quadratic Bezier formula
    let x = (1 - t) * (1 - t) * startX + 2 * (1 - t) * t * ctrlX + t * t * endX;
    let y = (1 - t) * (1 - t) * startY + 2 * (1 - t) * t * ctrlY + t * t * endY;
    let z = (1 - t) * (1 - t) * startZ + 2 * (1 - t) * t * ctrlZ + t * t * endZ;
    
    // Determine radial distance in the xz-plane
    let rDist = sqrt(x * x + z * z);
    if (rDist < dome_radius) {
      stroke(255, 0, 0);
      // Record the track point as a red dot
      trackPoints.push(createVector(x, y, z));
    } else {
      stroke(0, 255, 0);
    }
    strokeWeight(2);
    vertex(x, y, z);
  }
  endShape();
}

// Draw permanent track points (red spheres)
function drawTrackPoints() {
  push();
  noStroke();
  fill(255, 0, 0);
  for (let v of trackPoints) {
    push();
    translate(v.x, v.y, v.z);
    sphere(3);
    pop();
  }
  pop();
}
