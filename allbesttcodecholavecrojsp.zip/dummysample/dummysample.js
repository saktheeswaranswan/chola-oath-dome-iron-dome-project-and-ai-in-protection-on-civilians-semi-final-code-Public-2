// Global parameters
const dome_radius = 300;          // Inner dome radius
const second_dome_radius = 310;   // Outer dome (for reference)
let speed_factor = 0.5;

// Camera parameters
let zoom_factor = 1.0;

// Dome rotation variables (rotation about its center)
let domeRotationX = 0; // Rotation around horizontal axis (X-axis)
let domeRotationY = 0; // Rotation around vertical axis (Y-axis)

let video;
let patchSlider;

function setup() {
  createCanvas(800, 600, WEBGL);
  
  // Setup webcam capture (if needed)
  video = createCapture(VIDEO);
  video.size(320, 240);
  video.hide();
  
  // Slider (if needed for other purposes)
  patchSlider = createSlider(0.1, 1.0, 0.5, 0.01);
  patchSlider.position(20, 20);
}

function draw() {
  background(0);
  
  // Update dome rotation using keyboard arrow keys:
  // Left/right arrow keys rotate about the vertical (Y) axis.
  if (keyIsDown(LEFT_ARROW)) {
    domeRotationY -= 0.02 * speed_factor;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    domeRotationY += 0.02 * speed_factor;
  }
  // Up/down arrow keys rotate about the horizontal (X) axis.
  if (keyIsDown(UP_ARROW)) {
    domeRotationX -= 0.02 * speed_factor;
  }
  if (keyIsDown(DOWN_ARROW)) {
    domeRotationX += 0.02 * speed_factor;
  }
  
  // Fixed camera: Positioned along Z so the dome's rotation is clearly visible.
  let cam_distance = 1000 * zoom_factor;
  camera(0, dome_radius/2, cam_distance, 0, dome_radius/2, 0, 0, 1, 0);
  
  drawDome();
  drawBasePlane();
}

// Draw the hemispherical dome with rotation applied about its center.
function drawDome() {
  push();
  // Translate so that the dome's center (assumed at y = dome_radius/2) is the rotation pivot.
  translate(0, dome_radius/2, 0);
  // Apply dome rotations: First rotate about Y (side-to-side), then about X.
  rotateY(domeRotationY);
  rotateX(domeRotationX);
  // Translate back so that the dome is drawn in the proper location.
  translate(0, -dome_radius/2, 0);
  
  noStroke();
  fill(100, 100, 255, 50);
  let domeDetail = 30;
  for (let i = 0; i < domeDetail; i++) {
    let theta1 = map(i, 0, domeDetail, 0, PI/2);
    let theta2 = map(i + 1, 0, domeDetail, 0, PI/2);
    beginShape(TRIANGLE_STRIP);
    for (let j = 0; j <= domeDetail; j++) {
      let phi = map(j, 0, domeDetail, 0, TWO_PI);
      let x1 = dome_radius * sin(theta1) * cos(phi);
      let y1 = dome_radius * cos(theta1);
      let z1 = dome_radius * sin(theta1) * sin(phi);
      vertex(x1, y1, z1);
      
      let x2 = dome_radius * sin(theta2) * cos(phi);
      let y2 = dome_radius * cos(theta2);
      let z2 = dome_radius * sin(theta2) * sin(phi);
      vertex(x2, y2, z2);
    }
    endShape();
  }
  pop();
}

// Draw the base plane (flat circle) at y = 0.
function drawBasePlane() {
  push();
  noStroke();
  fill(150, 150, 150, 100);
  beginShape();
  let baseDetail = 100;
  for (let i = 0; i < baseDetail; i++) {
    let angle = map(i, 0, baseDetail, 0, TWO_PI);
    let x = dome_radius * cos(angle);
    let z = dome_radius * sin(angle);
    vertex(x, 0, z);
  }
  endShape(CLOSE);
  pop();
}

// Zoom using mouse wheel.
function mouseWheel(event) {
  zoom_factor = constrain(zoom_factor - event.delta * 0.001, 0.1, 5.0);
}
